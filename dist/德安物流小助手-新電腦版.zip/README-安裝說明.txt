德安物流小助手 - 更新包 說明
================================

【本次更新重點：運單列印】
1. 左側導航改為：全部訂單 / 運單列印 / 訂單報表 / 物流查詢 / 地址管理
2. 「運單列印」頁面
   - 設定並記住預設打印機（會自動挑 ZD420 標籤機）
   - 可搜尋訂單（支援逗號分隔多筆，例：042609000415,042609000414）
   - 可單選 / 多選 / 全選 / 取消全選，批次列印
3. 訂單小卡片右下角新增「快速列印」按鈕（用預設打印機）
4. 列印規則（自動判斷）
   - 選 ZD420 標籤機：A4 兩聯切開、旋轉縮放成 102x210mm，印 2 張
   - 選一般印表機：直接印 A4 整張
5. 修正
   - receiptFile 取層錯誤（改抓 Result[0].Order.Table[0]）
   - 缺少 PyPDF2 時會回報明確錯誤，不再出現無訊息 500
   - 預設打印機名稱會自動校正（舊的 "ZD420" 名稱不存在）
   - 默認打印機下拉選單文字看不到的問題（改為白字深底）

【更新步驟】
1. 把本壓縮檔解壓到專案資料夾（與 server.py 同一層），全部覆蓋
2. 雙擊 apply_update.bat（會自動重啟服務，不用重新登入）
3. 瀏覽器按 Ctrl+F5 強制重新整理

【重要：本次新增 Python 套件 PyPDF2】
- 若是全新電腦，請先執行 setup.bat（已包含 PyPDF2）
- 若沿用舊環境，請在專案資料夾執行一次：
  .venv\Scripts\python.exe -m pip install PyPDF2

【列印前檢查】
- keepalive 服務必須在跑（否則 token 過期會列印失敗）
- 伺服器啟動畫面會顯示：列印模組 PyPDF2: 可用 / 缺少

【本次修正（第二批）】
- 批量列印：改為使用「下拉框當前選擇的打印機」，不再只用已保存的預設機
  並記住你的選擇；列印時按鈕顯示進度（列印中 1/3...），完成後自動清除勾選
- setup.bat：pip 加 --no-cache-dir（避免裝到 ABI 不符的 wheel）
  並在驗證步驟檢查 greenlet（keepalive 必要模組）

【已知問題與解法：keepalive 出現 No module named 'greenlet._greenlet'】
原因：pip 快取裡的 greenlet wheel 是給 Python 3.14 的（cp314），
      裝進 3.12 的 venv 會缺少正確的編譯模組。
解法（任一）：
  A. 重建 venv（最乾淨）：
     rmdir /s /q .venv
     setup.bat
  B. 只重裝該套件：
     .venv\Scripts\python.exe -m pip install --force-reinstall --no-cache-dir greenlet
檢查是否已修好：
  .venv\Scripts\python.exe -c "import greenlet; print('ok')"
