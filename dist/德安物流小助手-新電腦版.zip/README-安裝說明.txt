德安物流小助手 - 更新包 說明
================================

【本次更新重點：運單列印】
1. 左側導航改為：全部訂單 / 運單列印 / 訂單報表 / 物流查詢 / 地址管理
2. 「運單列印」頁面
   - 設定並記住預設打印機（會自動挑 ZD420 標籤機）
   - 可搜尋訂單（支援逗號分隔多筆，例：042609000415,042609000414）
   - 可單選 / 多選 / 全選 / 取消全選，批次列印
3. 訂單小卡片右下角新增「快速列印」按鈕（用預設打印機）
4. 列印規則（自動判斷）
   - 選 ZD420 標籤機：A4 兩聯切開、旋轉縮放成 102x210mm，印 2 張
   - 選一般印表機：直接印 A4 整張
5. 修正
   - receiptFile 取層錯誤（改抓 Result[0].Order.Table[0]）
   - 缺少 PyPDF2 時會回報明確錯誤，不再出現無訊息 500
   - 預設打印機名稱會自動校正（舊的 "ZD420" 名稱不存在）
   - 默認打印機下拉選單文字看不到的問題（改為白字深底）

【更新步驟】
1. 把本壓縮檔解壓到專案資料夾（與 server.py 同一層），全部覆蓋
2. 雙擊 apply_update.bat（會自動重啟服務，不用重新登入）
3. 瀏覽器按 Ctrl+F5 強制重新整理

【重要：本次新增 Python 套件 PyPDF2】
- 若是全新電腦，請先執行 setup.bat（已包含 PyPDF2）
- 若沿用舊環境，請在專案資料夾執行一次：
  .venv\Scripts\python.exe -m pip install PyPDF2

【列印前檢查】
- keepalive 服務必須在跑（否則 token 過期會列印失敗）
- 伺服器啟動畫面會顯示：列印模組 PyPDF2: 可用 / 缺少

【本次修正（第二批）】
- 批量列印：改為使用「下拉框當前選擇的打印機」，不再只用已保存的預設機
  並記住你的選擇；列印時按鈕顯示進度（列印中 1/3...），完成後自動清除勾選
- setup.bat：pip 加 --no-cache-dir（避免裝到 ABI 不符的 wheel）
  並在驗證步驟檢查 greenlet（keepalive 必要模組）

【已知問題與解法：keepalive 出現 No module named 'greenlet._greenlet'】
原因：pip 快取裡的 greenlet wheel 是給 Python 3.14 的（cp314），
      裝進 3.12 的 venv 會缺少正確的編譯模組。
解法（任一）：
  A. 重建 venv（最乾淨）：
     rmdir /s /q .venv
     setup.bat
  B. 只重裝該套件：
     .venv\Scripts\python.exe -m pip install --force-reinstall --no-cache-dir greenlet
檢查是否已修好：
  .venv\Scripts\python.exe -c "import greenlet; print('ok')"

【送印方式重大修正】
原本用 PowerShell `Start-Process -Verb PrintTo -ArgumentList "印表機"` 送印 —— 這是錯的！
ShellExecute 不會把印表機名傳進 PDF 處理程式（Foxit）的 /t 參數，
結果：API 回 200、但標籤機佇列全程 0 個工作，畫面還會彈 Foxit 列印對話框。

已改為讀取註冊表中 PDF 處理程式的 printto 指令列（例：Foxit 的 /t "%1" "%2"）自己組命令，
實測可正常進標籤機佇列。若首選方式不可用，會依序退回 PrintTo → 系統預設印表機。

API 回應新增 send_method 欄位，可看出實際走哪條路徑（例：PDF 處理程式指令列: FoxitPDFEditor.exe）。

診斷指令（送印前後各看一次，工作若從未出現 = 根本沒送進去）：
  powershell -c "Get-PrintJob -PrinterName 'ZD420 (192.168.168.251)' | Select Id,DocumentName,JobStatus"

【送印方式再升級：不再需要 Foxit】
前一版用「PDF 處理程式的 printto 指令」送印，但那要求電腦裝了 Foxit/Acrobat。
現改為：本程式自己把 PDF 點陣化成 ZPL，直接送到印表機的 9100 埠（Zebra raw 埠）。
→ 不需要任何 PDF 閱讀程式、不需要 Windows 驅動，任何一台電腦都能印。
→ 送印前會自動從印表機名稱取得 IP（例：ZD420 (192.168.168.251) → 192.168.168.251）。

若該路徑不可用（例如非網路印表機），會依序退回：
  PDF 處理程式指令列 → ShellExecute PrintTo → 系統預設印表機

新增 Python 套件 PyMuPDF（setup.bat 已包含；舊環境請補跑一次：
  .venv\Scripts\python.exe -m pip install --no-cache-dir pymupdf

驗證送印（ZPL 直送不會出現在 Windows 佇列，改用印表機查詢）：
  ~HI → 機型/韌體   ~HS → 狀態（第1行第4欄為標籤長度 dots）

【送印順序調整 + 標籤 PDF 重建】
1. 送印順序改為：Adobe Reader(`/h /t`) 為首選（A4 與標籤都用），
   ZPL 直送 9100 作為標籤機的備選。API 可用 channel 參數強制：auto|pdf|zpl。
2. 標籤 PDF 改以 PyMuPDF show_pdf_page 重建（乾淨版）。
   原因：舊的 PyPDF2「mediabox + transformation」寫法 Foxit 能印，但
   Adobe Reader 會靜默拒絕（目標印表機佇列全程 0 個工作）。
3. Adobe 送印自動加 /h，避免彈出文件視窗。
4. A4 分支不再改寫 PDF，原檔 1:1 直出。

【實測（暫停佇列法，零耗紙）】
- 乾淨版標籤 PDF：2 頁，各 102.0 x 210.0 mm，皆有內容
- Reader /h /t → ZD420：pages=2、6 秒進 Printing、無殘留視窗
- ZPL 備選：可由同一份 PDF 產生 685556 bytes（2 個 ^XA）
