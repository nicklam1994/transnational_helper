德安物流小助手 — 更新說明
================================

【本次更新重點：列印引擎改為原生路徑，不再使用 Adobe / Foxit】（2026-09-21）

■ 為什麼要改
  舊版把 PDF 交給 Adobe Reader `/h /t` 列印，實際問題：
  1. Adobe 的結束碼不可靠 —— 明明印成功了也可能回傳 1；程式誤判失敗後又走別條路徑
     再送一次 → 同一份工作送兩次。使用者回報的「快速列印出 4 張（應 2 張）」
     「批量 3 筆只出 1 張」「原單 A4 第 2/3 張變成標籤格式」全部源自這條鏈。
  2. 即使加了 /h，Adobe 仍會短暫彈出視窗。
  3. `Start-Process -Verb PrintTo` 不會把印表機名傳進 PDF 程式 → 彈窗、工作不進佇列。
  4. 不是每台電腦都裝 Foxit / Acrobat。

■ 現在的列印方式（完全不需要任何 PDF 程式）
  在「運單列印」頁左上選模式：
  1. 原單 (A4)     → PDF 以 300dpi 點陣化 → 經印表機驅動 GDI 直印 → A4 印表機，1 張
  2. 標籤機        → A4 兩聯自動切開、旋轉縮放成 102x210mm → GDI 直印 → 標籤機，2 張
  3. 標簽機 (ZPL)  → 程式自行轉成 ZPL，直送印表機 raw 埠 9100（不經 Windows 驅動）
  三種模式全部無對話框、無彈窗；「回傳成功」= 工作已確實進入列印佇列
  （EndDoc 會等 spooler 收下工作才回報）。

■ 安裝／更新步驟
  1. 解壓本壓縮檔到專案資料夾（與 server.py 同一層），全部覆蓋
  2. 雙擊 apply_update.bat（自動重啟服務，不用重新登入）
  3. 瀏覽器按 Ctrl+F5 強制重新整理
  4. 到左下 ⚙️「設定」選好：
     - 原始運單打印機 (A4)
     - 標籤運單打印機 (Label)
     - 標籤機 IP（例：192.168.168.252）與埠 9100

■ 本次新增 Python 套件：pywin32、pillow（本機直印必需）
  - 全新電腦：執行 setup.bat 即可（已包含全部套件）
  - 沿用舊環境：在專案資料夾執行一次
      .venv\Scripts\python.exe -m pip install --no-cache-dir pywin32 pillow
  - 伺服器啟動畫面應顯示：
      列印模組 PyPDF2:  ✓ 可用
      標籤直送 PyMuPDF: ✓ 可用（ZPL 直送 IP:埠）
      本機直印 GDI:     ✓ 可用（pywin32，無對話框）
    若出現「✗ 缺少」→ 依上面 pip 指令補裝後重啟服務。

■ 如何確認真的印了（不耗紙的檢查法）
  - A4 / 標籤：先暫停印表機，送印後看佇列
      powershell -c "Set-Printer -Name 'HP_P1102w_192.168.168.253' -Paused $true"
      powershell -c "Get-PrintJob -PrinterName 'HP_P1102w_192.168.168.253'"
      看到工作 = 路徑通；看完可 Remove-PrintJob 再 -Paused $false 恢復
  - ZPL 直送不會出現在 Windows 佇列，要用印表機自身查詢：~HI（機型）/ ~HS（狀態）

■ 其他沿用功能
  - 地址管理（新增/編輯/刪除/搜尋，國家→城市→地區→區域連動）
  - 訂單報表（日/月/年；Cancelled 以刪除線顯示）
  - 物流查詢；訂單篩選（狀態多選 + 日期）
  - Keepalive 自動保活（Edge CDP 5 秒輪詢，零網路請求）
  - 深色 / 淺色主題

【列印前提醒】
  - keepalive 必須在跑（token 過期會導致列印失敗，回應會寫「無法獲取 token」）

【標籤列印修正：點點點 與 logo／文字缺失（2026-09-22）】
問題一：GDI 直印標籤機 → 紙上很多細碎點點（雜訊）。
  根因：ZD420 驅動實測係 1-bit 單色 / 原生 203dpi / 畫布 815x1678，
        但舊版用 300dpi「彩色 RGB」點陣圖再縮到 815x1678 →
        ① 300→203dpi 最近鄰降採樣把細線與文字邊緣打散
        ② GDI 把彩色轉 1bpp 會做抖動（halftone）→ 全頁散佈細點
  修正：改為依印表機 DC 實測規格送圖 —— 以原生解析度點陣化、與畫布 1:1（不做二次縮放），
        DC 係 1-bit 就先硬門檻二值化再送。實測孤立雜點 251 → 32（-87%）。
        另 A4 嘅 HP 驅動 DC 係 8-bit 灰階 / 600dpi，維持灰階直送，不再被放大失真。

問題二：ZPL 直送標籤機 → logo 同部分文字缺失。
  根因：二值化門檻寫死 128，把「非純黑」全部判成白色刪掉：
        · Transnational logo 灰階 96~249（平均 169）→ 整塊消失
        · 灰色分區色帶 灰階 165（上面係白色反白字 COLLECT FROM / DELIVER TO）
          → 色帶連字一齊消失
        · 全頁墨點被砍 55.3%
  修正：新增共用常數 INK_THRESHOLD = 200，GDI 同 ZPL 兩條路徑共用，輸出一致。
        實測：logo 完整回來、灰帶變「實心黑底 + 白色反白字」（符合原設計）、
        孤立雜點 41 → 4、只砍 10.5% 墨點。
        門檻 235 會過度加粗故不採用。

注意：如覺得整體太黑，可調 ZDesigner 驅動嘅 Darkness 值（唔需改程式）。

【本版追加：A4 變形修正 + 三項新功能（2026-09-22）】
■ 修正：A4 收據經 GDI 印出後比例與原始 PDF 不同
  原因：上一版用 x/y 各自縮放（非等比）去填滿可列印區，A4 內容被水平拉長 8.83%。
  修正：改為單一倍率等比縮放 + 置中（完全不變形）。
  提示：HP 驅動紙張目前是 Letter，所以 A4 內容會縮成 91.3%（比例正確）；若把驅動紙張改成 A4 就會是 100% 原寸。
■ 新功能：
  1) 全部訂單／運單列印／訂單報表 三頁自動刷新（預設 30 秒；設定頁可改間隔或關閉；
     正在輸入／彈窗開啟／列印中會自動跳過，且保留搜尋、過濾、勾選、報表期間與捲動位置）。
  2) 「快速列印」與運單列印頁的列印方式預設改為「原單 (A4)」。
  3) 運單列印頁新增「🔔 新單監聽自動列印」：開關 + 列印方式（預設原單 A4）。
     開啟時會把現有訂單記為基準（不會補印舊單），之後每 20 秒檢查新單並自動列印，
     逐筆間隔 1.2 秒並記錄最近 30 筆；預設關閉。

【依賴檢查與修復（2026-09-22）】
問題：更新包只替換 app.html / server.py，不會補裝新依賴。目標機若缺 pywin32 / pillow，
      程式會照跑但列印功能靜默失效。而重新執行 setup.bat 時，若舊服務仍在跑，
      pip 會因檔案被鎖而寫入不完整 —— PyMuPDF 的 mupdfcpp64.dll（25MB）不完整就會出現：
        ImportError: DLL load failed while importing _extra: The specified module could not be found.
      （已在開發機完整複現：刪掉該 DLL 即得到一模一樣的錯誤；且與 Python 3.14 無關）

本版新增／修改：
  · check_deps.py （新）依賴檢查／自動修復
        .venv\Scripts\python.exe check_deps.py            檢查，有問題自動修復
        .venv\Scripts\python.exe check_deps.py --verify   只檢查（有問題回傳 1）
        .venv\Scripts\python.exe check_deps.py --repair   強制清乾淨重裝
      逐項檢查 9 個模組、檢查 PyMuPDF 三個原生檔案是否齊全、檢查 VC++ 執行檔；
      修復後用「新行程」複驗（pywin32 靠 .pth 加路徑，同一行程複驗會出現假失敗）。
  · repair_deps.bat （新）一鍵修復：關服務 → check_deps.py --repair → 可選自動重啟
  · setup.bat       重寫：先關服務（避免檔案被鎖）、優先選 Python 3.12/3.13、
                    強制 wheel 安裝（--only-binary=:all:，客戶機不需編譯器）、最後呼叫 check_deps.py
  · apply_update.bat 更新流程新增「依賴檢查」步驟（第 2/4 步），缺依賴會自動補裝
  · server.py       改用 import pymupdf as fitz，消除 fitz 相容層的 deprecation 警告

實測（Python 3.14.7 全新環境）：setup.bat 全流程成功、21 個套件全部以 wheel 安裝、
依賴檢查全 OK（rc=0）；刪掉 mupdfcpp64.dll 後 repair_deps.bat 20 秒修復成功。
註：setup.bat / repair_deps.bat 都會先關閉正在運行的服務（避免安裝時檔案被鎖 —— 那正是
    過去造成 mupdfcpp64.dll 寫入不完整、出現 DLL load failed 的原因）。
    所以跑完 setup.bat 之後，請再雙擊 start_server.bat 把服務重新啟動。

【第二個根因：系統缺少 VC++ 執行檔（2026-09-22 實際案例，已解決）】
目標機跑 repair_deps.bat 的輸出顯示：
    PyMuPDF 原生檔案全部完好：_extra.pyd 0.2MB / _mupdf.pyd 12.5MB / mupdfcpp64.dll 25.1MB
    但 Visual C++ 執行檔 (System32): 缺少 msvcp140.dll, vcruntime140.dll, vcruntime140_1.dll
→ 重裝 PyMuPDF 完全沒用！因為 _extra.pyd 與 win32ui.pyd 必須靠 MSVC runtime 才能載入。
  那台機是全新安裝的 Windows，沒有裝 VC++ 2015-2022 Redistributable。

本版新增：
  · install_vcruntime.bat（新）一鍵修好：自動下載（約 24MB）並以系統管理員權限靜默安裝
      VC++ 2015-2022 Redistributable (x64)。用法：右鍵 → 以系統管理員身分執行 → UAC 按「是」。
  · check_deps.py 修復流程改為「先補系統 runtime，再考慮重裝套件」：
      若補上 runtime 後套件已全部正常，就完全不重裝（實測：pip 呼叫次數 0，省 20MB 下載）。
  · 失敗訊息改為優先指出「缺少 VC++ 執行檔」，不再誤導人去重裝套件。
  · repair_deps.bat 失敗時會提示先執行 install_vcruntime.bat。

若 install_vcruntime.bat 說仍有檔案缺失 → 重新開機後再跑 repair_deps.bat 一次。

【README 更新（2026-09-22）】
README.md 已更新，補充：
  · 自動刷新功能（全部訂單/運單列印/訂單報表，預設 30 秒）
  · 新單監聽自動列印（預設原單 A4，每 20 秒檢查新訂單）
  · 依賴檢查與修復機制（check_deps.py / repair_deps.bat / install_vcruntime.bat）
  · 故障排查章節（列印失效、Token 失效、自動刷新不工作）
  · 安裝步驟補充 VC++ runtime 說明（全新 Windows 常缺）
